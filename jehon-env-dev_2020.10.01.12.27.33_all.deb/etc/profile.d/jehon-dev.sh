#!/usr/bin/env bash

# Use this variable to protect the main computer
export IS_REAL=1
